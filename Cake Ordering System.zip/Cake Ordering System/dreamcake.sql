-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 19, 2021 at 03:58 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dreamcake`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `o_id` int NOT NULL AUTO_INCREMENT,
  `p_id` int NOT NULL,
  `u_id` int NOT NULL,
  `o_quantity` int NOT NULL,
  `o_date` varchar(450) NOT NULL,
  PRIMARY KEY (`o_id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `pay_id` int NOT NULL AUTO_INCREMENT,
  `u_id` int NOT NULL,
  `o_id` int NOT NULL,
  `amount` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`pay_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(450) NOT NULL,
  `category` varchar(450) NOT NULL,
  `price` double NOT NULL,
  `image` varchar(450) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `price`, `image`) VALUES
(1, '', 'anniversary', 2500, 'anniversary.jpg'),
(2, '', 'anniversary', 3000, 'anniversary2.jpg'),
(3, '', 'anniversary', 1500, 'anniversary3.jpg'),
(4, '', 'anniversary', 0, 'anniversary4.jpg'),
(5, '', 'anniversary', 0, 'anniversary5.jpg'),
(8, '', 'Birthday Cake', 2500, 'b.jpg'),
(9, '', 'Birthday Cake', 0, 'b2.jpg'),
(10, '', 'Birthday Cake', 0, 'b3.jpg'),
(11, '', 'Birthday Cake', 0, 'b4.jpg'),
(12, '', 'Birthday Cake', 0, 'b5.jpg'),
(13, '', 'Christmas Cake', 0, 'c.jpg'),
(14, '', 'Christmas Cake', 0, 'c1.jpg'),
(16, '', 'Christmas Cake', 0, 'c2.jpg'),
(17, '', 'Christmas Cake', 0, 'c3.jpg'),
(18, '', 'Christmas Cake', 0, 'c4.jpg'),
(20, '', 'Special Occasion Cake', 0, 's1.jpg'),
(21, '', 'Special Occasion Cake', 0, 's2.jpg'),
(22, '', 'Special Occasion Cake', 0, 's3.jpg'),
(23, '', 'Special Occasion Cake', 0, 's4.jpg'),
(24, '', 'Special Occasion Cake', 0, 's5.jpg'),
(25, '', 'Special Occasion Cake', 0, 's6.jpg'),
(26, '', 'Wedding Cake ', 0, 'w1.jpg'),
(27, '', 'Wedding Cake ', 0, 'w2.jpg'),
(28, '', 'Wedding Cake ', 0, 'w3.jpg'),
(29, '', 'Wedding Cake ', 0, 'w4.jpg'),
(30, '', 'Wedding Cake ', 0, 'w5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
